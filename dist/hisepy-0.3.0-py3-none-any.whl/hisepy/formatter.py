""" formatter.py

Description:

Contributors: James Harvey
"""

# libraries
import os

import h5py
import pandas as pd
import json
from hisepy.logging import with_default_logging, logger
import hisepy.common_utils as cu

# setting global config
_here = os.path.abspath(os.path.dirname(__file__))
CONFIG = cu.read_yaml('{}/config.yaml'.format(_here))


def attach_project_info_to_df(df):
    """ Adds project information to a data.frame object. data.frame object must have projectGuid column
    """
    # get projects
    proj_df = cu.get_projects()

    # add 'project' prefix to project columns
    proj_df = proj_df.add_prefix('project.')

    # merge project info to data.frame
    return pd.merge(df,
                    proj_df,
                    how='left',
                    left_on='projectGuid',
                    right_on='project.guid')


def convert_data_values(filepath: str, filetype: str):
    try:
        if filetype == 'csv':
            return pd.read_csv(filepath)
        elif filetype == 'h5':
            return h5py.File(filepath, mode='r')
        else:
            return None
    except:
        raise Exception(
            "Uh-oh, the file wasn't downloaded into the /cache directory")


def convert_single_val_to_df(df, single_val, col_name):
    """ Converts a single value to a data.frame object
    """
    assert (type(single_val) is str) or (type(single_val) is int) or (
        type(single_val) is bool
    ), "Expected a single value to be of type str, int, or bool. Received type %s" % type(
        single_val)
    single_df_tmp = pd.DataFrame([single_val], columns=[col_name])
    df = pd.concat([df, single_df_tmp], axis=1)
    return df


def convert_dict_to_df(df, dict_val, col_name, add_prefix=True):
    """ Converts a dictionary to a data.frame object
    """
    assert type(
        dict_val
    ) is dict, "Expected a dictionary to be of type dict. Received type %s" % type(
        dict_val)
    dict_val.update(
        (k, [v]) for k, v in dict_val.items() if type(dict_val[k]) is not list)
    dict_val.update((k, v.append('')) for k, v in dict_val.items()
                    if type(v) is list and len(v) == 0)
    dict_df_tmp = pd.DataFrame.from_dict(dict_val)
    if add_prefix:
        dict_df_tmp = dict_df_tmp.add_prefix('{}.'.format(col_name))
    else:
        pass
    df = pd.concat([df, dict_df_tmp], axis=1)
    return df


def convert_list_to_df(df, list_val, col_name):
    # if there's just 1 entry, convert it to a data.frame
    if len(list_val) == 1 and type(list_val[0]) is not dict:
        df = convert_single_val_to_df(df, list_val[0], col_name)
    elif len(list_val) > 1:
        df = convert_single_val_to_df(df, str(list_val), col_name)
    else:
        # we have a dictionary with possibly multiple entries
        for this_dict in list_val:
            df = convert_dict_to_df(df, this_dict, col_name)
    return df


def reshape_custom_metadata(custom_metadata, add_prefix=True):
    """Takes a json payload and reshapes to a DataFrame object."""
    rows = {}  # collect scalar-like values
    frames = []  # collect nested dict/list frames

    for dk, this_entry in custom_metadata.items():
        if this_entry is None:
            rows[dk] = ""
        elif isinstance(this_entry, dict):
            if len(this_entry) == 0:
                rows[dk] = ""
            else:
                frames.append(
                    convert_dict_to_df(pd.DataFrame(), this_entry, dk,
                                       add_prefix))
        elif isinstance(this_entry, (str, bool, int)):
            rows[dk] = this_entry
        elif isinstance(this_entry, list):
            frames.append(convert_list_to_df(pd.DataFrame(), this_entry, dk))
        else:
            raise ValueError(
                f"Unexpected entry for key {dk}: {type(this_entry)}")

    base_df = pd.DataFrame([rows]) if rows else pd.DataFrame()
    if frames:
        return pd.concat([base_df] + frames, axis=1, ignore_index=False)
    return base_df


@with_default_logging
def subject_to_df(list_subject_out):
    subject_df = reshape_custom_metadata(list_subject_out[0])
    if len(list_subject_out) > 1:
        for i in range(1, len(list_subject_out)):
            tmp_df = reshape_custom_metadata(list_subject_out[i])
            subject_df = pd.concat([subject_df, tmp_df], ignore_index=True)
    return subject_df


def _dict_to_df(input_df, col_name):
    """
    This function takes a column from a data.frame and converts that column to its
    own data.frame object
    NOTE: the column you specify must have entries that are of type dict

        Parameters:
            input_df : pd.dataframe
                pandas dataframe
            col_name : str
                column name that exists in your input_df
        Returns:
            fin_df : pd.dataframe
                pandas data.frame
    """
    # subset to just the column of interest
    this_df = input_df.copy(deep=True)[[col_name]].reset_index(drop=True)
    fin_df = pd.DataFrame()
    for i in range(0, len(this_df)):
        this_dict = this_df[col_name].values[i]
        if this_dict is not None:
            this_dict.update((k, [v]) for k, v in this_dict.items())
            fin_df = pd.concat(
                [fin_df, pd.DataFrame.from_dict(this_dict)], ignore_index=True)
    return fin_df


def reshape_list_metadata_to_df(spec_obj):
    """Given a list of specimens, returns a DataFrame object."""
    # build all rows first, then concat once
    frames = [
        reshape_custom_metadata(spec) for spec in spec_obj if spec is not None
    ]
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def reshape_survey_results_to_df(survey_obj):
    """
    Converts a survey result dictionary into a flattened DataFrame, even when
    some fields contain multiple values.
    """
    if survey_obj is None:
        return pd.DataFrame()

    # convert answers section first
    ans_df = convert_dict_to_df(pd.DataFrame(), survey_obj.get('answers', {}),
                                'answers')

    # normalize the rest of the survey fields
    meta_dict = {k: v for k, v in survey_obj.items() if k != 'answers'}

    # make all entries lists of equal length
    # find max length among all list-type values
    max_len = max(
        (len(v) if isinstance(v, list) else 1) for v in meta_dict.values())

    normalized = {}
    for k, v in meta_dict.items():
        if isinstance(v, list):
            # if shorter than max_len, pad with None
            normalized[k] = v + [None] * (max_len - len(v))
        else:
            # repeat scalar to match max_len
            normalized[k] = [v] * max_len

    meta_df = pd.DataFrame(normalized)

    # combine metadata with answers
    surv_df = pd.concat([meta_df, ans_df.reset_index(drop=True)], axis=1)

    return surv_df


def sample_to_df(list_of_sample_obj):
    """
    Given a list of outputs from readSamples(), returns the same data but in a dictionary of DataFrames format.
    Each sample’s projectGuid is propagated to all its corresponding records.
    """

    if not list_of_sample_obj:
        return pd.DataFrame()

    # Collect all per-sample frames
    all_specimens = []
    all_surveys = []
    all_labs = []
    all_metadata = []

    for sample in list_of_sample_obj:
        # extract projectGuid from this sample’s metadata
        base_df = reshape_custom_metadata({
            k: v
            for k, v in sample.items()
            if k not in ['specimens', 'survey', 'lab']
        })
        project_guid = (base_df["projectGuid"].iat[0]
                        if "projectGuid" in base_df and not base_df.empty else
                        None)

        # specimens
        if "specimens" in sample:
            spec_df = reshape_list_metadata_to_df(sample["specimens"])
            spec_df = spec_df.assign(projectGuid=project_guid)
            all_specimens.append(spec_df)

        # survey
        if "survey" in sample:
            for surv in sample["survey"]:
                surv_df = reshape_survey_results_to_df(surv)
                surv_df = surv_df.assign(projectGuid=project_guid)
                all_surveys.append(surv_df)

        # lab
        if sample.get("hasLabResults") and "lab" in sample:
            lab_df = reshape_custom_metadata(sample["lab"], False)
            lab_df = lab_df.assign(projectGuid=project_guid)
            all_labs.append(lab_df)

        # metadata
        all_metadata.append(base_df)

    # combine all results
    def concat_frames(frames):
        return pd.concat(frames,
                         ignore_index=True) if frames else pd.DataFrame()

    sample_df_dict = {
        "metadata": concat_frames(all_metadata),
        "specimens": concat_frames(all_specimens),
        "survey": concat_frames(all_surveys),
        "labResults": concat_frames(all_labs),
    }

    return sample_df_dict


def reshape_descriptors(this_desc):
    """Reshapes descriptors to a dataframe object."""
    if not isinstance(this_desc, dict):
        raise TypeError(
            f"expected descriptors to be a dictionary. got {type(this_desc)}")

    # Prepare results
    dict_df = {}

    # Handle lab results
    lab_df = pd.DataFrame()
    if "lab" in this_desc:
        lab_df = reshape_custom_metadata(this_desc["lab"], False)
        this_desc = {
            k: v
            for k, v in this_desc.items() if k != "lab"
        }  # avoid mutating input

    # Handle specimens
    spec_df = pd.DataFrame()
    if "specimens" in this_desc:
        if this_desc["specimens"]:
            spec_df = reshape_list_metadata_to_df(this_desc["specimens"])
        this_desc = {k: v for k, v in this_desc.items() if k != "specimens"}

    # Handle survey
    surv_df = pd.DataFrame()
    if "survey" in this_desc:
        if this_desc["survey"]:
            surv_df = reshape_list_metadata_to_df(this_desc["survey"])
        this_desc = {k: v for k, v in this_desc.items() if k != "survey"}

    # Remaining descriptors
    dict_df = {
        "descriptors": reshape_custom_metadata(this_desc),
        "labResults": lab_df,
        "specimens": spec_df,
        "survey": surv_df,
    }

    # Extract projectGuid once
    this_proj_guid = dict_df["descriptors"]["projectGuid"].iat[0]

    # Attach projectGuid to all relevant DataFrames at once
    for key in ("labResults", "specimens", "survey"):
        df = dict_df[key]
        # Assign using assign() to create a new DataFrame
        dict_df[key] = df.assign(projectGuid=this_proj_guid)

    return dict_df


@with_default_logging
def hise_file_to_df(list_of_hise_files):
    """
    Given a list of hise_file objects, return a dictionary containing a data.frame of descriptors, and a data.frame of lab results

        Parameters:
            list_of_hise_files : list
                a list of hise_file objects

        Returns:
            final_dict : dictionary with keys {'descriptors',labResults', 'specimens', 'values'} which are all data.frame objects.
            except for values, which depends on the filetype the user passes in.
    """
    list_dict = []
    values_df = pd.DataFrame()
    values_list = []
    errors_df = pd.DataFrame()
    for i in range(0, len(list_of_hise_files)):
        # deal with any failed downloads
        if list_of_hise_files[i].status is False:
            errors_df = pd.concat([
                errors_df,
                pd.DataFrame(
                    data={
                        'filetype': [list_of_hise_files[0].filetype],
                        'id': [list_of_hise_files[0].id],
                        'message': [list_of_hise_files[0].message]
                    })
            ],
                                  ignore_index=True)
            continue
        this_desc = list_of_hise_files[i].descriptors
        filetype = list_of_hise_files[i].filetype
        if type(this_desc) is list:
            for olink_desc in this_desc:
                tmp_df = reshape_descriptors(olink_desc)
                list_dict += [tmp_df]

        elif type(this_desc) is dict:
            tmp_df = reshape_descriptors(this_desc)
            list_dict += [tmp_df]

        # create an object of data values for a given data type
        if filetype == 'csv':
            # attach file_name
            list_of_hise_files[i].data_values['filename'] = str(
                list_of_hise_files[i].descriptors['file']['name'][0])
            values_df = pd.concat(
                [values_df, list_of_hise_files[i].data_values],
                ignore_index=True)
        elif filetype == 'h5':
            values_list.append(list_of_hise_files[i].data_values)

    # if everything failed, don't create data.frames
    all_files_not_found = all(item.status is False
                              for item in list_of_hise_files)
    desc_df = pd.DataFrame()
    lab_df = pd.DataFrame()
    spec_df = pd.DataFrame()
    if all_files_not_found:
        return {
            'descriptors': desc_df,
            'labResults': lab_df,
            'specimens': spec_df,
            'values': [],
            'errors': errors_df
        }
    else:
        # go through all results from read_files() output, and create a master dictionary
        # then parse through and append appropriately

        for i in range(0, len(list_dict)):
            desc_df = pd.concat([desc_df, list_dict[i]['descriptors']],
                                ignore_index=True)
            lab_df = pd.concat([lab_df, list_dict[i]['labResults']],
                               ignore_index=True)
            spec_df = pd.concat([spec_df, list_dict[i]['specimens']],
                                ignore_index=True)

        if filetype == 'csv':
            data_values = values_df
        elif filetype == 'h5':
            data_values = values_list
        else:  # don't return anything useful under values
            data_values = []
        final_dict = {
            'descriptors': desc_df,
            'labResults': lab_df,
            'specimens': spec_df,
            'values': data_values,
            'errors': errors_df
        }
        return final_dict
